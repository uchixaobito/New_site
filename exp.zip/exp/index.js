const express = require("express");
const app = express();
const path = require("path")

const port = process.env.PORT || 5527;
app.use(express.static(path.join(__dirname, 'views')));


app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname,"views","index.html"))
});
app.get("/yangiliklar", (req, res) => {
  res.sendFile(path.join(__dirname,"views","yangiliklar.html"))
});





app.listen(port, () => console.log(`Server running on port ${port} 🔥`));